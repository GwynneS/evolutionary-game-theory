# Evolutionary Game Theory, Markov Chains, and Linear Algebra Simulator

This project is a C++ computational model of repeated strategic interaction. It combines game theory, Markov chains, linear algebra, and evolutionary dynamics to study how different decision-making strategies perform and evolve over time.

The central question is:

> How do cooperation strategies change when repeated interactions include memory, mistakes, long-run state transitions, and evolutionary selection?

## Main Components

### 1. Repeated Prisoner's Dilemma

Each pair of strategies plays a repeated Prisoner's Dilemma.

The default payoff matrix is

\[
A =
\begin{bmatrix}
3 & 0 \\
5 & 1
\end{bmatrix}.
\]

The simulation includes a discount factor

\[
U = \sum_{t=0}^{T-1} \delta^t u_t
\]

so future payoffs can be valued differently from immediate payoffs.

The program also allows action errors, so a player can accidentally take the opposite action from the one its strategy intended.

### 2. Strategy Set

The current model includes:

- Always Cooperate
- Always Defect
- Tit for Tat
- Grim Trigger
- Win-Stay Lose-Shift
- Generous Tit for Tat

### 3. Strategy Payoff Matrix

After the repeated games are simulated, the program constructs an evolutionary payoff matrix

\[
P =
\begin{bmatrix}
p_{11} & \cdots & p_{1n} \\
\vdots & \ddots & \vdots \\
p_{n1} & \cdots & p_{nn}
\end{bmatrix},
\]

where \(p_{ij}\) is the average payoff received by strategy \(i\) against strategy \(j\).

If

\[
x =
\begin{bmatrix}
x_1 \\
\vdots \\
x_n
\end{bmatrix}
\]

is the population vector, then strategy fitness is

\[
f = Px.
\]

The average population fitness is

\[
\bar{f} = x^T P x.
\]

### 4. Replicator Dynamics

The project uses the replicator equation

\[
\dot{x}_i
=
x_i
\left(
f_i-\bar{f}
\right)
\]

to model how strategy frequencies evolve.

A small mutation parameter can also be added to stop strategies from disappearing permanently.

The program exports the population trajectory to

```text
population_history.csv
```

so the results can be graphed.

### 5. Markov Chain Model

For memory-one strategy interactions, each round is represented by one of four states:

\[
CC,\quad CD,\quad DC,\quad DD.
\]

These states form a Markov chain with transition matrix

\[
M =
\begin{bmatrix}
p_{11} & p_{12} & p_{13} & p_{14} \\
p_{21} & p_{22} & p_{23} & p_{24} \\
p_{31} & p_{32} & p_{33} & p_{34} \\
p_{41} & p_{42} & p_{43} & p_{44}
\end{bmatrix}.
\]

The stationary distribution \(\pi\) satisfies

\[
M^T \pi = \pi.
\]

The code approximates the stationary distribution through repeated matrix-vector multiplication.

That distribution gives the long-run probability of observing each interaction state.

The project then calculates long-run expected payoffs directly from the stationary distribution.

### 6. Linear Algebra

The project implements its own basic linear algebra functions instead of relying on an external matrix library.

These include:

- matrix-vector multiplication
- matrix-matrix multiplication
- transpose
- dot product
- probability-vector normalization
- iterative stationary-distribution calculation

This makes the mathematical operations visible in the source code.

### 7. Optional Black-Scholes Extension

A separate computational-finance module implements the Black-Scholes call option formula

\[
C
=
S_0N(d_1)
-
Ke^{-rT}N(d_2).
\]

This module is independent from the main evolutionary-game model.

## Files

```text
main.cpp
strategies.cpp
strategies.h
simulation.cpp
simulation.h
linear_algebra.cpp
linear_algebra.h
markov.cpp
markov.h
dynamics.cpp
dynamics.h
csv_utils.cpp
csv_utils.h
finance.cpp
finance.h
```

## Compile

On macOS:

```bash
clang++ -std=c++17 main.cpp strategies.cpp simulation.cpp linear_algebra.cpp markov.cpp dynamics.cpp csv_utils.cpp finance.cpp -o simulator
```

With g++:

```bash
g++ -std=c++17 main.cpp strategies.cpp simulation.cpp linear_algebra.cpp markov.cpp dynamics.cpp csv_utils.cpp finance.cpp -o simulator
```

## Run

```bash
./simulator
```

The program produces:

```text
payoff_matrix.csv
population_history.csv
markov_transition_matrix.csv
```

## Experiments

Some useful experiments include:

- vary the discount factor and measure when cooperative strategies become dominant
- increase action-error probability and measure how cooperation changes
- compare Tit for Tat and Generous Tit for Tat under noise
- examine how the stationary distribution moves between CC, CD, DC, and DD
- introduce mutation into the replicator model
- compare equilibrium populations under different Prisoner's Dilemma payoffs
- measure how much time each strategy pair spends in mutual cooperation
- compare simulated repeated-game payoffs with Markov-chain long-run payoffs

## Research Direction

A possible research question for the project is:

> How does implementation error change the long-run stability of cooperative strategies in repeated Prisoner's Dilemma populations?

This can be studied through both the Markov stationary distribution and the evolutionary population model.
